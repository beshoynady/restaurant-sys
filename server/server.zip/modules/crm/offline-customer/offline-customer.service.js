import OfflineCustomerModel from "./offline-customer.model.js";
import AdvancedService from "../../../utils/BaseService.js";

// Initialize service for offline-customer model
const offlineCustomerService = new AdvancedService(OfflineCustomerModel, {
  brandScoped: true,
  softDelete: true,
  defaultPopulate: ["brand","branch","createdBy","updatedBy","deletedBy"],
  searchFields: [], // specify searchable fields if needed
  defaultSort: { createdAt: -1 },
});

export default offlineCustomerService;
