// attendance-settings router - placeholder
