// attendance-settings service - placeholder
