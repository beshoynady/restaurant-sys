// attendance-settings model - placeholder
