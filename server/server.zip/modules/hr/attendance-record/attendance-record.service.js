import AttendanceRecordModel from "./attendance-record.model.js";
import AdvancedService from "../../../utils/BaseService.js";

// Initialize service for attendance-record model
const attendanceRecordService = new AdvancedService(AttendanceRecordModel, {
  brandScoped: true,
  softDelete: true,
  defaultPopulate: ["brand","branch","employee","shift","leaveRequest","createdBy","updatedBy"],
  searchFields: [], // specify searchable fields if needed
  defaultSort: { createdAt: -1 },
});

export default attendanceRecordService;
