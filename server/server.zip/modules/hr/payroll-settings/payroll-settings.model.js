// payroll-settings model - placeholder
