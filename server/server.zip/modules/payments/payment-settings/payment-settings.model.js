// payment-settings model - placeholder
