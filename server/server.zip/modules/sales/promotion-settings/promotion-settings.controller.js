// promotion-settings controller - placeholder
