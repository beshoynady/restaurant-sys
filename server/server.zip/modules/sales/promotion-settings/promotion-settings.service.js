// promotion-settings service - placeholder
