// promotion-settings router - placeholder
