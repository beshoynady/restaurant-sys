// promotion-settings model - placeholder
